/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author son
 */
public class Room {

    private String roomId;
    private String roomName;
    private String description;
    private double price;
    private String state;
    private Position position;
    private Customer customer;
    private String image;

    public Room() {
    }

    public Room(String roomId, String roomName, String description, double price, Position position, Customer customer, String image) {
        this.roomId = roomId;
        this.roomName = roomName;
        this.description = description;
        this.price = price;
        this.position = position;
        this.customer = customer;
        this.image = image;
    }

    public Room(String roomId, String roomName, String description, double price, String state, Position position, Customer customer, String image) {
        this.roomId = roomId;
        this.roomName = roomName;
        this.description = description;
        this.price = price;
        this.state = state;
        this.position = position;
        this.customer = customer;
        this.image = image;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId;
    }



  
    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

}
